<?php
/**
 * Template for oauth login button.
 *
 * @package DaxHurley\OAuthLogin
 * @since 1.0.0
 */

use DaxHurley\OAuthLogin\Utils\Helper;

if ( isset( $custom_btn_text ) && $custom_btn_text ) {
	$button_text = esc_html( $custom_btn_text );
} else {
	$button_text = ( ! empty( $button_text ) ) ? $button_text : __( 'Login with OAuth', 'wp-oauth-login' );
}

if ( empty( $login_url ) ) {
	return;
}

$button_url = $login_url;

if ( is_user_logged_in() ) {
	$button_text  = __( 'Log out', 'wp-oauth-login' );
	$redirect_url = Helper::get_redirect_url();
	$button_url   = wp_logout_url( $redirect_url );
}

// Get provider name for display
$provider_name = isset( $provider_name ) ? $provider_name : __( 'OAuth Provider', 'wp-oauth-login' );

// Determine if this is a shortcode or block (not the default WP login page)
$is_shortcode_or_block = isset( $css_classes ) || isset( $disable_styles ) || isset( $force_display_block );

// Get provider configuration for customization
$provider_config = isset( $provider_config ) ? $provider_config : [];
$button_icon = $provider_config['button_icon'] ?? '';
$button_color = $provider_config['button_color'] ?? '';

// Build CSS classes
$container_classes = 'wp_oauth_login';
if ( $is_shortcode_or_block ) {
	$container_classes .= ' wp_oauth_login--shortcode';
}
if ( ! empty( $css_classes ) ) {
	$container_classes .= ' ' . esc_attr( $css_classes );
}

// Build button styles
$button_styles = '';
if ( ! empty( $button_color ) && ( ! isset( $disable_styles ) || $disable_styles !== 'yes' ) ) {
	$button_styles .= 'background-color: ' . esc_attr( $button_color ) . ';';
}

// Build icon styles
$icon_styles = '';
if ( ! empty( $button_icon ) ) {
	$icon_styles .= 'background-image: url("' . esc_url( $button_icon ) . '");';
}

?>
<div class="<?php echo esc_attr( $container_classes ); ?>">
	<div
		<?php
		if ( ! isset( $disable_styles ) || $disable_styles !== 'yes' ) {
			echo 'class="wp_oauth_login__button-container"';
		}
		?>
	>
		<a
			<?php
			if ( ! isset( $disable_styles ) || $disable_styles !== 'yes' ) {
				echo 'class="wp_oauth_login__button"';
			}
			printf( ' href="%s"', esc_url( $button_url ) );
			if ( ! empty( $button_styles ) ) {
				printf( ' style="%s"', esc_attr( $button_styles ) );
			}
			?>
		>
			<?php if ( ! empty( $button_icon ) ): ?>
				<span class="wp_oauth_login__oauth-icon" style="<?php echo esc_attr( $icon_styles ); ?>"></span>
			<?php endif; ?>
			<?php echo esc_html( $button_text ); ?>
			<?php if ( ! is_user_logged_in() && ! isset( $custom_btn_text ) && ! empty( $provider_name ) ): ?>
				<span class="wp_oauth_login__provider-name">(<?php echo esc_html( $provider_name ); ?>)</span>
			<?php endif; ?>
		</a>
	</div>
</div>
<?php
